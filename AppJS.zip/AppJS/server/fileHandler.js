const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

const SECRET_KEY = '12345678901234567890123456789012'; // 32 bytes
const ALGORITHM = 'aes-256-cbc';
const FILE_PATH = path.join(__dirname, '..', 'data', 'users.json');

function encryptData(data) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(SECRET_KEY), iv);
    let encrypted = cipher.update(JSON.stringify(data));
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
}

function decryptData(data) {
    if (!data) return [];
    const [ivHex, encryptedHex] = data.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const encryptedText = Buffer.from(encryptedHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(SECRET_KEY), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return JSON.parse(decrypted.toString());
}

exports.loadUsers = () => {
    if (!fs.existsSync(FILE_PATH)) return [];
    const encrypted = fs.readFileSync(FILE_PATH, 'utf8');
    return decryptData(encrypted);
};

exports.saveUsers = (users) => {
    const encrypted = encryptData(users);
    fs.writeFileSync(FILE_PATH, encrypted);
};
