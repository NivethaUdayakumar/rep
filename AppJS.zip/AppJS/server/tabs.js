const fs = require('fs');
const path = require('path');
const sessionStore = require('./sessionStore');

const roleAccess = {
    home: ['user', 'admin', 'prioritized'],
    profile: ['user', 'admin', 'prioritized'],
    settings: ['admin']
};

exports.loadTab = (req, res) => {
    const cookie = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
    if (!cookie) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Not logged in' }));
    }

    const token = cookie.split('=')[1];
    const session = sessionStore.validateSession(token);
    if (!session) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Session expired' }));
    }

    const tabName = new URL(req.url, `http://${req.headers.host}`).searchParams.get('name');
    if (!roleAccess[tabName] || !roleAccess[tabName].includes(session.role)) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Access denied' }));
    }

    let view = `${tabName}.html`;
    if (tabName === 'profile') {
        view = session.role === 'admin' ? 'profile_admin.html' : 'profile_user.html';
    }
    const filePath = path.join(__dirname, 'tab-views', view);
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, message: 'Tab not found' }));
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
    });
};
