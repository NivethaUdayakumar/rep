
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const fileHandler = require('./fileHandler');

function ensureUser(session, res) {
  if (!session) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success:false, message:'Not logged in' }));
    return false;
  }
  return true;
}

exports.me = (session, res) => {
  if (!ensureUser(session, res)) return;
  const users = fileHandler.loadUsers();
  const user = users.find(u => u.username === session.username);
  const photoUrl = user?.photo ? `/public/uploads/${user.photo}` : null;
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success:true, username: session.username, photoUrl }));
};

exports.verifyPassword = (session, data, res) => {
  if (!ensureUser(session, res)) return;
  const { password } = data || {};
  const users = fileHandler.loadUsers();
  const user = users.find(u => u.username === session.username);
  if (!user) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'User not found' }));
  }
  const hashed = crypto.createHash('sha256').update(password || '').digest('hex');
  const ok = user.password === hashed;
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: ok }));
};

exports.changePassword = (session, data, res) => {
  if (!ensureUser(session, res)) return;
  const { oldPassword, newPassword } = data || {};
  if (!oldPassword || !newPassword) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Missing fields' }));
  }
  const users = fileHandler.loadUsers();
  const idx = users.findIndex(u => u.username === session.username);
  if (idx < 0) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'User not found' }));
  }
  const oldHash = crypto.createHash('sha256').update(oldPassword).digest('hex');
  if (users[idx].password !== oldHash) {
    res.writeHead(403, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Old password incorrect' }));
  }
  const newHash = crypto.createHash('sha256').update(newPassword).digest('hex');
  users[idx].password = newHash;
  fileHandler.saveUsers(users);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success:true }));
};

exports.uploadPhoto = (session, data, res) => {
  if (!ensureUser(session, res)) return;
  const { dataUrl } = data || {};
  if (!dataUrl || !dataUrl.startsWith) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Invalid image' }));
  }
  const header = 'base64,';
  const i = dataUrl.indexOf(header);
  if (i < 0) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Invalid data URL' }));
  }
  const meta = dataUrl.slice(5, i-1); // e.g., image/png
  const ext = (meta.split('/')[1] || 'png').split(';')[0];
  const b64 = dataUrl.slice(i + header.length);
  let buf;
  try { buf = Buffer.from(b64, 'base64'); } catch { buf = null; }
  if (!buf || buf.length > 2 * 1024 * 1024) { // 2MB limit
    res.writeHead(400, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Bad image or too large' }));
  }
  const uploadsDir = path.join(__dirname, '..', 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
  const name = `${session.username}.${ext}`;
  fs.writeFileSync(path.join(uploadsDir, name), buf);
  const users = fileHandler.loadUsers();
  const idx = users.findIndex(u => u.username === session.username);
  if (idx >= 0) { users[idx].photo = name; fileHandler.saveUsers(users); }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success:true, photoUrl: `/public/uploads/${name}` }));
};
