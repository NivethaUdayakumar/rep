const crypto = require('crypto');

const sessions = {};
const SESSION_EXPIRY = 1000 * 60 * 30; // 30 minutes

function createSession(username, role) {
    const token = crypto.randomBytes(16).toString('hex');
    sessions[token] = { username, role, expiry: Date.now() + SESSION_EXPIRY };
    return token;
}

function validateSession(token) {
    const session = sessions[token];
    if (!session || Date.now() > session.expiry) {
        delete sessions[token];
        return null;
    }
    return session;
}

function destroySession(token) {
    delete sessions[token];
}

module.exports = { createSession, validateSession, destroySession };
