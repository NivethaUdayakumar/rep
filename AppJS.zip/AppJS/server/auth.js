const crypto = require('crypto');
const fileHandler = require('./fileHandler');
const sessionStore = require('./sessionStore');

function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

exports.login = (data, res) => {
    const users = fileHandler.loadUsers();
    const user = users.find(u => u.username === data.username && u.password === hashPassword(data.password));
    if (user) {
        const token = sessionStore.createSession(user.username, user.role);
        res.writeHead(200, {
            'Content-Type': 'application/json',
            'Set-Cookie': `session=${token}; HttpOnly; Path=/`
        });
        return res.end(JSON.stringify({ success: true }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: false, message: 'Invalid credentials' }));
};

exports.register = (data, res) => {
    const users = fileHandler.loadUsers();
    if (users.some(u => u.username === data.username)) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Username already exists' }));
    }
    users.push({ username: data.username, password: hashPassword(data.password), role: data.role });
    fileHandler.saveUsers(users);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true }));
};

exports.checkSession = (req, res) => {
    const cookie = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
    if (!cookie) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Not logged in' }));
    }
    const token = cookie.split('=')[1];
    const session = sessionStore.validateSession(token);
    if (!session) {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: false, message: 'Session expired' }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, username: session.username, role: session.role }));
};

exports.logout = (req, res) => {
    const cookie = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
    if (cookie) sessionStore.destroySession(cookie.split('=')[1]);
    res.writeHead(200, {
        'Content-Type': 'application/json',
        'Set-Cookie': 'session=; Max-Age=0; Path=/'
    });
    res.end(JSON.stringify({ success: true }));
};
