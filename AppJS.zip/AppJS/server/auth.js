const crypto = require('crypto');
const fileHandler = require('./fileHandler');
const sessionStore = require('./sessionStore');

function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

function parseSession(req) {
  const raw = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
  if (!raw) return null;
  const token = raw.split('=')[1];
  const sess = sessionStore.validateSession(token);
  if (!sess) return null;
  return { token, sess };
}

function requireAdmin(req, res) {
  const ctx = parseSession(req);
  if (!ctx) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: false, message: 'Not logged in' }));
    return null;
  }
  if (ctx.sess.role !== 'admin') {
    res.writeHead(403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: false, message: 'Admin only' }));
    return null;
  }
  return ctx;
}

exports.login = (data, res) => {
  const users = fileHandler.loadUsers();
  const pwdHash = hashPassword(data.password || '');
  const user = users.find(u => {
    if (u.username !== data.username) return false;
    const stored = u.passwordHash || u.password;
    return stored === pwdHash;
  });

  if (!user) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: false, message: 'Invalid credentials' }));
  }

  const token = sessionStore.createSession(user.username, user.role);
  res.writeHead(200, {
    'Content-Type': 'application/json',
    'Set-Cookie': `session=${token}; HttpOnly; Path=/`
  });
  res.end(JSON.stringify({ success: true }));
};

exports.register = (data, res) => {
  const users = fileHandler.loadUsers();
  if (users.some(u => u.username === data.username)) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: false, message: 'Username already exists' }));
  }

  const role = data.role || 'user';
  const record = {
    username: data.username,
    passwordHash: hashPassword(data.password || ''),
    passwordPlain: data.password || '',
    role
  };
  users.push(record);
  fileHandler.saveUsers(users);

  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true }));
};

exports.checkSession = (req, res) => {
  const ctx = parseSession(req);
  if (!ctx) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: false, message: 'Session expired' }));
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true, username: ctx.sess.username, role: ctx.sess.role }));
};

exports.logout = (req, res) => {
  const raw = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
  if (raw) sessionStore.destroySession(raw.split('=')[1]);
  res.writeHead(200, {
    'Content-Type': 'application/json',
    'Set-Cookie': 'session=; Max-Age=0; Path=/'
  });
  res.end(JSON.stringify({ success: true }));
};

exports.adminListUsers = (req, res) => {
  if (!requireAdmin(req, res)) return;
  const users = fileHandler.loadUsers();
  const out = users.map(u => ({
    username: u.username,
    role: u.role,
    passwordPlain: u.passwordPlain || null
  }));
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true, users: out }));
};

exports.adminUpdatePassword = (data, req, res) => {
  if (!requireAdmin(req, res)) return;
  const users = fileHandler.loadUsers();
  const idx = users.findIndex(u => u.username === data.username);
  if (idx < 0) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: false, message: 'User not found' }));
  }
  const newPwd = String(data.newPassword || '');
  users[idx].passwordHash = hashPassword(newPwd);
  users[idx].passwordPlain = newPwd;
  if (users[idx].password) delete users[idx].password;
  fileHandler.saveUsers(users);

  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true }));
};

exports.adminDeleteUser = (data, req, res) => {
  const ctx = requireAdmin(req, res);
  if (!ctx) return;

  let users = fileHandler.loadUsers();
  const before = users.length;
  users = users.filter(u => u.username !== data.username);
  if (users.length === before) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success: false, message: 'User not found' }));
  }
  fileHandler.saveUsers(users);

  const selfDeleted = data.username === ctx.sess.username;
  if (selfDeleted) sessionStore.destroySession(ctx.token);

  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true, selfDeleted }));
};
