
const fileHandler = require('./fileHandler');

function ensureAdmin(session, res) {
  if (!session || session.role !== 'admin') {
    res.writeHead(403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success:false, message:'Admin only' }));
    return false;
  }
  return true;
}

exports.listUsers = (session, res) => {
  if (!ensureAdmin(session, res)) return;
  const users = fileHandler.loadUsers().map(u => ({ username: u.username, role: u.role, photo: !!u.photo }));
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success:true, users }));
};

exports.resetPassword = (session, data, res) => {
  if (!ensureAdmin(session, res)) return;
  const { username, newPassword } = data || {};
  if (!username || !newPassword) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'Missing fields' }));
  }
  const users = fileHandler.loadUsers();
  const idx = users.findIndex(u => u.username === username);
  if (idx < 0) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ success:false, message:'User not found' }));
  }
  const crypto = require('crypto');
  const hashed = crypto.createHash('sha256').update(newPassword).digest('hex');
  users[idx].password = hashed;
  fileHandler.saveUsers(users);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success:true }));
};
