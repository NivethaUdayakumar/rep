const fs = require('fs');
const path = require('path');
const auth = require('./auth');
const tabs = require('./tabs');

module.exports = (req, res) => {
    if (req.method === 'GET') {
        const cookie = req.headers.cookie?.split('; ').find(c => c.startsWith('session='));
        const token = cookie ? cookie.split('=')[1] : null;
        const session = require('./sessionStore').validateSession(token);
        if (req.url === '/admin/users') return require('./userAdmin').listUsers(session, res);
        if (req.url === '/me') return require('./userSelf').me(session, res);

        // Session & Tab APIs
        if (req.url === '/check-session') return auth.checkSession(req, res);
        if (req.url === '/logout') return auth.logout(req, res);
        if (req.url.startsWith('/tab?name=')) return tabs.loadTab(req, res);

        // Serve static files (login, register, dashboard, semantic UI)
        let filePath = path.join(__dirname, '..', 'public', req.url === '/' ? 'index.html' : req.url);
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404);
                return res.end('Not found');
            }
            let contentType = 'text/html';
            if (filePath.endsWith('.css')) contentType = 'text/css';
            if (filePath.endsWith('.js')) contentType = 'application/javascript';
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
        });
    }

    if (req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            const parsed = JSON.parse(body);
            if (req.url === '/login') return auth.login(parsed, res);
            if (req.url === '/register') return auth.register(parsed, res);
        });
    }
};
