document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = {
      username: e.target.username.value,
      password: e.target.password.value
    };
    const res = await fetch('/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(formData)
    });
    const data = await res.json();
    if (data.success) {
      window.location.href = '/dashboard.html';
    } else {
      const errorDiv = document.getElementById('error');
      errorDiv.style.display = 'block';
      errorDiv.innerText = data.message || 'Login failed';
    }
  });
  