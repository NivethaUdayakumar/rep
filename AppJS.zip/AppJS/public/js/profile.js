// adminUserManager.js
export function initAdminUserManager(root = document) {
  const table = root.querySelector('#user-table');
  if (!table) return;

  const tbody = table.querySelector('tbody');

  async function loadUsers() {
    const r = await fetch('/admin/users', { credentials: 'include' });
    const j = await r.json();
    if (!j.success) { alert(j.message || 'Failed to load users'); return; }
    tbody.innerHTML = '';
    j.users.forEach(u => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${u.username}</td>
        <td>${u.role}</td>
        <td>${u.passwordPlain !== null ? u.passwordPlain : '(not available)'}</td>
        <td><input type="password" placeholder="New password" data-user="${u.username}"></td>
        <td>
          <button data-action="set" data-user="${u.username}">Set password</button>
          <button data-action="del" data-user="${u.username}">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  // scoped events to this table only
  table.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn || !table.contains(btn)) return;

    const username = btn.getAttribute('data-user');
    const action = btn.getAttribute('data-action');

    if (action === 'set') {
      const input = table.querySelector(`input[data-user="${username}"]`);
      const newPassword = input?.value.trim();
      if (!newPassword) { alert('Enter a new password'); return; }
      const r = await fetch('/admin/users/updatePassword', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, newPassword })
      });
      const j = await r.json();
      if (j.success) { alert('Password updated'); loadUsers(); }
      else { alert(j.message || 'Failed to update password'); }
    }

    if (action === 'del') {
      if (!confirm(`Delete user ${username}?`)) return;
      const r = await fetch('/admin/users/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username })
      });
      const j = await r.json();
      if (j.success) {
        if (j.selfDeleted) {
          alert('You deleted your own account, you will be logged out');
          location.href = '/';
        } else {
          loadUsers();
        }
      } else {
        alert(j.message || 'Failed to delete user');
      }
    }
  });

  // initial render
  loadUsers();

  // return controls if you want to refresh from outside
  return { reload: loadUsers };
}