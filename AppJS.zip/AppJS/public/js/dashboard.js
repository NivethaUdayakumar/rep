import { initAdminUserManager } from './profile.js';

async function checkSession() {
    const res = await fetch('/check-session');
    const data = await res.json();
    if (!data.success) {
      window.location.href = 'index.html';
      return;
    }
    if (data.role !== 'admin') {
      document.getElementById('settingsTab').style.display = 'none';
      document.getElementById('profileTab').style.display = 'none';
    }
    return data.role;
  }
  
  async function loadTab(tab) {
    const res = await fetch(`/tab?name=${tab}`);
    if (!res.ok) {
      document.getElementById('tabContent').innerHTML = `<h3>Access Denied</h3>`;
      return;
    }
    const html = await res.text();
    document.getElementById('tabContent').innerHTML = html;
    if (tab === 'profile') {
      initAdminUserManager(tabContent); // runs the table logic inside the loaded HTML
    }
  }
  
  document.getElementById('logout').addEventListener('click', async () => {
    await fetch('/logout');
    window.location.href = 'index.html';
  });
  
  document.querySelectorAll('.dashboard-menu .item[data-tab]').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.dashboard-menu .item[data-tab]').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      loadTab(item.getAttribute('data-tab'));
    });
  });
  
  (async () => {
    await checkSession();
    loadTab('home');
  })();
  